package demo;
// @author Duong Nguyen
public class Message {
    
    public static String DARK_GREEN_COLOR = "#004867";
    public static String GREEN_COLOR = "#0079a0";
    public static String BLUE_SKY_COLOR = "#96c3e2";
    public static String DARK_BLUE_SKY_COLOR = "#015ea1";
    public static String BLUE_COLOR = "#00147b";
    public static String DARK_GRAY = "#262626";
    public static String CURRENT_DIRECTORY = System.getProperty("user.dir");
    public static String JIRA_COOKIE_PATH = CURRENT_DIRECTORY + "\\cookies.txt";
    public static String USER_PROXY_PATH = CURRENT_DIRECTORY + "\\proxy.lg";
    public static String DIALOG_OPEN_FILE_TITLE = "Open File";
    public static String DIALOG_OPEN_FOLDER_TITLE = "Open Folder";
    public static String ERROR_TITLE = "Error";
    public static String MESSAGE_TITLE = "Message";
    public static String PLEASE_INPUT_INFORMATION = "Please input your information!";
    public static String CAN_NOT_SAVE_YOUR_INFORMATION = "Can not save your information!";
    public static String PROXY_AUTHENTICATION_BY = "Proxy authentication by: ";
    public static String BACK_TO_LOGIN_FORM = "You will return to Login form!";
    public static String EXAMPLE_FOLDER_STRUCTURE = "This is example to preview your tree folder structure";
    public static String BUTTON_LOAD_TOOLTIP = "Click Load button to preview before apply";
    public static String SPECIAL_CHARACTER = "[/|\\||:|?|<|>]";
    public static String EXCEL_FILE_IS_FORMATTED_INCORRECT = "Excel file is formatted incorrect!";
    public static String CANNOT_READ_YOUR_FILE = "Can not read your file!";
    public static String CLICK_TO_CREATE_FOLDER_TOOLTIP = "Click to create folders";
    public static String DIRECTORY_CREATE_AS_BELOW = "Your directory will be created as below";
    public static String EXCEL_FILE_DOES_NOT_EXIST = "Excel file does not exist!";
    public static String FOLDER_DOES_NOT_EXIST = "Folder does not exist!";
    public static String CREATE_FOLDER_SUCCESSFULLY = "Create folders successfully!";
    public static String PDF_FORMAT_FILE = "PDF - Portable Document Format";
    public static String JPEG_FORMAT_FILE = "JPEG - Joint Photographic Experts Group";
    public static String PNG_FORMAT_FILE = "PNG - Portable Network Graphics";
    public static String GETTING_DATA_AND_CONVERTER = "Getting data and Converter";
    public static String CANNOT_SET_PROXY_AUTHENTICATION = "Can not set proxy authentication!\nPlease restart program!";
    public static String GETTING_PAGE_INFORMATION = "Getting page information...";
    public static String ENJOY_WITH_YOUR_COFFEE = "Keep calm, drink a coffee and waiting...";
    public static String PROGRESSING = "Progressing...";
    public static String CANNOT_OPEN_WEB_BROWSER = "Can not open web browser!";
    public static String CHOOSE_FOLDER_TO_SAVE_FILE = "Please choose a folder to save your file!";
    public static String PLEASE_TYPE_TICKET_NUMBER = "Please type number of the ticket!";
    public static String PLEASE_CHOOSE_FORMAT_FILE = "Please choose your file format!";
    public static String CANNOT_START_PROGRAM = "Can not start!\nProgram has problem. Please re-install program!";
    public static String CANNOT_GET_PAGE_INFORMATION = "Can not get the page information, please try again!\nMake sure that your ticket exists!";
}