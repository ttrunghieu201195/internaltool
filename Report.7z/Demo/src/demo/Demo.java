package demo;
// @author Duong Nguyen
import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Demo {
    public static void main(String a[]) {
        String sprint = "202";
        String url = "https://jira.renesas.eu/browse/IDE-11467?filter=-1&jql=project%20%3D%20IDE%20AND%20issuetype%20in%20"
                + "(Bug%2C%20%22Change%20Control%22%2C%20%22Document%20Task%22%2C%20Epic%2C%20Feature%2C%20Improvement%2C%20%22Product%20"
                + "Specification%22%2C%20Task)%20AND%20Sprint%20%3D%20" + sprint + "%20AND%20assignee%20in%20(currentUser())%20ORDER%20BY%20updatedDate%20DESC";
        System.setProperty("https.proxyHost", "172.29.137.2");
        System.setProperty("https.proxyPort", "8080");
        // skip tunnel through proxy since Java 8 Update 111
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        Authenticator.setDefault(new ProxyAuthenticator("nguyenduong", "renesas@1234"));
        try {
            Connection.Response loginForm = Jsoup.connect("https://jira.renesas.eu/")
                .method(Connection.Method.GET)
                .execute();
            Document doc = Jsoup.connect(url).timeout(5000)
                .data("os_username", "nguyen.duong.uw")
                .data("os_password", "nguyen08147")
                .data("login", "Login")
                .cookies(loginForm.cookies())
                .get();
            Elements list = doc.getElementsByClass("issue-list");
            Elements elements = list.get(0).getElementsByAttribute("data-key");
            for (int i = 0; i < elements.size(); i++) {
                System.out.print(elements.get(i).attr("data-key") + ": ");
                System.out.println(elements.get(i).attr("title"));
            }
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
    }
    
    
    public static class ProxyAuthenticator extends Authenticator {
        private final String user;
        private final String password;

        public ProxyAuthenticator(String user, String password) {
            this.user = user;
            this.password = password;
        }

        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(user, password.toCharArray());
        }
    }
}