package demo;
// @author Duong Nguyen
import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Demo2 {
    public static void main(String a[]) {
        String url = "https://jira.renesas.eu/browse/IDE-14788?page=com.atlassian.jira.plugin.system.issuetabpanels:all-tabpanel";
        System.setProperty("https.proxyHost", "172.29.137.2");
        System.setProperty("https.proxyPort", "8080");
        // skip tunnel through proxy since Java 8 Update 111
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        Authenticator.setDefault(new ProxyAuthenticator("nguyenduong", "renesas@1234"));
        try {
            Connection.Response loginForm = Jsoup.connect("https://jira.renesas.eu/")
                .method(Connection.Method.GET)
                .execute();
            Document doc = Jsoup.connect(url).timeout(5000)
                .data("os_username", "nguyen.duong.uw")
                .data("os_password", "nguyen08147")
                .data("login", "Login")
                .cookies(loginForm.cookies())
                .get();
            Element body = doc.getElementById("issue_actions_container");
            Elements table = body.getElementsByTag("table");
            System.out.println(table.size());
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
    }
    
    
    public static class ProxyAuthenticator extends Authenticator {
        private final String user;
        private final String password;

        public ProxyAuthenticator(String user, String password) {
            this.user = user;
            this.password = password;
        }

        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(user, password.toCharArray());
        }
    }
}