package demo;
// @author Duong Nguyen
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class MainFrame extends javax.swing.JFrame {
    
    public MainFrame() {
        initComponents();
        buildGUI();
    }
    
    public final void buildGUI() {
        setBanner(jlbPicture.getWidth(), jlbPicture.getHeight());
        this.setLocationRelativeTo(null);
        this.pack();
    }
    
    public void setBanner(int width, int height) {
        try {
            BufferedImage bufferedImg = ImageIO.read(this.getClass().getClassLoader().getResource("img/banner.jpg"));
            Image image = bufferedImg.getScaledInstance(width, height,
                Image.SCALE_SMOOTH);
            jlbPicture.setIcon(new ImageIcon(image));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, Message.CANNOT_START_PROGRAM,
                Message.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnMain = new javax.swing.JPanel();
        pnHeader = new javax.swing.JPanel();
        jlbTitle = new javax.swing.JLabel();
        pnCenter = new javax.swing.JPanel();
        pnPicture = new javax.swing.JPanel();
        jlbPicture = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        pnContent = new javax.swing.JPanel();
        jtfTemplates = new javax.swing.JTextField();
        jlbTemplates = new javax.swing.JLabel();
        jbtBrowseTemplates = new javax.swing.JButton();
        jlbOutputFile = new javax.swing.JLabel();
        jtfOutputFile = new javax.swing.JTextField();
        jbtOutputFile = new javax.swing.JButton();
        jlbSprints = new javax.swing.JLabel();
        jcbSprints = new javax.swing.JComboBox<>();
        jspTable = new javax.swing.JScrollPane();
        jtbIssues = new javax.swing.JTable();
        jlbNote = new javax.swing.JLabel();
        pnFooter = new javax.swing.JPanel();
        jlbGenerate = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnHeader.setBackground(new java.awt.Color(8, 67, 135));
        pnHeader.setPreferredSize(new java.awt.Dimension(581, 157));

        jlbTitle.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jlbTitle.setForeground(new java.awt.Color(255, 255, 255));
        jlbTitle.setText("REPORT FAST AND FASTER...");

        javax.swing.GroupLayout pnHeaderLayout = new javax.swing.GroupLayout(pnHeader);
        pnHeader.setLayout(pnHeaderLayout);
        pnHeaderLayout.setHorizontalGroup(
            pnHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnHeaderLayout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addComponent(jlbTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnHeaderLayout.setVerticalGroup(
            pnHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnHeaderLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jlbTitle)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pnCenter.setBackground(new java.awt.Color(255, 255, 255));

        pnPicture.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout pnPictureLayout = new javax.swing.GroupLayout(pnPicture);
        pnPicture.setLayout(pnPictureLayout);
        pnPictureLayout.setHorizontalGroup(
            pnPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbPicture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jSeparator1)
        );
        pnPictureLayout.setVerticalGroup(
            pnPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPictureLayout.createSequentialGroup()
                .addComponent(jlbPicture, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnContent.setBackground(new java.awt.Color(255, 255, 255));
        pnContent.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jtfTemplates.setEditable(false);
        jtfTemplates.setFont(new java.awt.Font("Tahoma", 2, 12)); // NOI18N
        jtfTemplates.setText("This is excel report templates directory");

        jlbTemplates.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jlbTemplates.setText("Excel templates");

        jbtBrowseTemplates.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jbtBrowseTemplates.setText("...");
        jbtBrowseTemplates.setToolTipText("Input");

        jlbOutputFile.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jlbOutputFile.setText("Excel output file");

        jtfOutputFile.setEditable(false);
        jtfOutputFile.setFont(new java.awt.Font("Tahoma", 2, 12)); // NOI18N
        jtfOutputFile.setText("This is excel report output directory");

        jbtOutputFile.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jbtOutputFile.setText("...");
        jbtOutputFile.setToolTipText("Output");

        jlbSprints.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jlbSprints.setText("Active Sprints");

        jcbSprints.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jcbSprints.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout pnContentLayout = new javax.swing.GroupLayout(pnContent);
        pnContent.setLayout(pnContentLayout);
        pnContentLayout.setHorizontalGroup(
            pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnContentLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnContentLayout.createSequentialGroup()
                        .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlbOutputFile)
                            .addComponent(jlbTemplates))
                        .addGap(27, 27, 27)
                        .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnContentLayout.createSequentialGroup()
                                .addComponent(jtfTemplates, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtBrowseTemplates, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnContentLayout.createSequentialGroup()
                                .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jcbSprints, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtfOutputFile, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtOutputFile, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jlbSprints))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        pnContentLayout.setVerticalGroup(
            pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnContentLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlbTemplates)
                    .addComponent(jtfTemplates, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtBrowseTemplates))
                .addGap(18, 18, 18)
                .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlbOutputFile)
                    .addComponent(jtfOutputFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtOutputFile))
                .addGap(18, 18, 18)
                .addGroup(pnContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlbSprints)
                    .addComponent(jcbSprints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jspTable.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jtbIssues.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "TicketID", "Component", "Story point", "Description", "Previous status", "Current status", "Re-Opened?", "Remark"
            }
        ));
        jtbIssues.getTableHeader().setReorderingAllowed(false);
        jspTable.setViewportView(jtbIssues);

        jlbNote.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jlbNote.setText("<html>\n<b>&nbsp;Note:</b><br><br>\n<b>&nbsp;Step 1: </b>&nbsp;Select excel templates file. <br>&nbsp;Ex: DebuggerGUIPluginReport_Member_V1.2<br>\n<b>&nbsp;Step 2: </b>&nbsp;Select a folder to save excel output file.<br>\n<b>&nbsp;Step 3: </b>&nbsp;Choose your Sprint.<br>\n<b>&nbsp;Step 4: </b>&nbsp;Click Generate Now.<br>\n</html>");
        jlbNote.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jlbNote.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout pnCenterLayout = new javax.swing.GroupLayout(pnCenter);
        pnCenter.setLayout(pnCenterLayout);
        pnCenterLayout.setHorizontalGroup(
            pnCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnPicture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(pnCenterLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jspTable)
                    .addGroup(pnCenterLayout.createSequentialGroup()
                        .addComponent(pnContent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jlbNote, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pnCenterLayout.setVerticalGroup(
            pnCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnCenterLayout.createSequentialGroup()
                .addComponent(pnPicture, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(pnCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnContent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlbNote, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspTable, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE))
        );

        pnFooter.setBackground(new java.awt.Color(8, 67, 135));

        jlbGenerate.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jlbGenerate.setForeground(new java.awt.Color(255, 255, 255));
        jlbGenerate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlbGenerate.setText("GENERATE NOW");
        jlbGenerate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout pnFooterLayout = new javax.swing.GroupLayout(pnFooter);
        pnFooter.setLayout(pnFooterLayout);
        pnFooterLayout.setHorizontalGroup(
            pnFooterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbGenerate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnFooterLayout.setVerticalGroup(
            pnFooterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbGenerate, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout pnMainLayout = new javax.swing.GroupLayout(pnMain);
        pnMain.setLayout(pnMainLayout);
        pnMainLayout.setHorizontalGroup(
            pnMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnCenter, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnFooter, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 920, Short.MAX_VALUE)
        );
        pnMainLayout.setVerticalGroup(
            pnMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnMainLayout.createSequentialGroup()
                .addComponent(pnHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnCenter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnFooter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        java.awt.EventQueue.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton jbtBrowseTemplates;
    private javax.swing.JButton jbtOutputFile;
    private javax.swing.JComboBox<String> jcbSprints;
    private javax.swing.JLabel jlbGenerate;
    private javax.swing.JLabel jlbNote;
    private javax.swing.JLabel jlbOutputFile;
    private javax.swing.JLabel jlbPicture;
    private javax.swing.JLabel jlbSprints;
    private javax.swing.JLabel jlbTemplates;
    private javax.swing.JLabel jlbTitle;
    private javax.swing.JScrollPane jspTable;
    private javax.swing.JTable jtbIssues;
    private javax.swing.JTextField jtfOutputFile;
    private javax.swing.JTextField jtfTemplates;
    private javax.swing.JPanel pnCenter;
    private javax.swing.JPanel pnContent;
    private javax.swing.JPanel pnFooter;
    private javax.swing.JPanel pnHeader;
    private javax.swing.JPanel pnMain;
    private javax.swing.JPanel pnPicture;
    // End of variables declaration//GEN-END:variables
}