package writefileexcel;
// @author Duong Nguyen
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class WriteFileExcel {
    
    public static String browseTheFolder() {
        JFileChooser fileSave = new JFileChooser();
        fileSave.setDialogTitle("Save File");
        fileSave.addChoosableFileFilter(new FileTypeFilter(".xls", 
                "Excel 97-2003 Workbook"));
//        fileSave.addChoosableFileFilter(new FileTypeFilter(".xlsx", 
//                "Excel Workbook"));
        fileSave.setAcceptAllFileFilterUsed(false);
        try {
            if (fileSave.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                String path = fileSave.getSelectedFile().getAbsolutePath();
//                String extension = ((FileTypeFilter) fileSave.getFileFilter()).getExtension();
//                if (!path.isEmpty()) {
//                    if (path.endsWith(".xls") || path.endsWith(".xlsx")) {
//                        return path;
//                    } else {
//                        return path + extension;
//                    }
//                }
                if (!path.isEmpty()) {
                    if (path.endsWith(".xls")) {
                        return path;
                    } else {
                        return path + ".xls";
                    }
                }
            }
        } catch (Exception e) { }
        return "";
    }
    
    public static void main(String[] args) {
        String fileName = browseTheFolder(); System.err.println(fileName);
        String header[] = {"Feature", "Assignee", "FS", "DS", "UT", "JUnit", "IT", "Manual", "Note"};
        ArrayList<String[]> data = new ArrayList<>();
        data.add(new String[]{"1", "Nguyễn Văn Quân", "YES", "NO", "YES", "NO", "NO", "NO", "abc"});
        data.add(new String[]{"2", "Phạm Thị Hà", "NO", "YES", "YES", "NO", "YES", "NO", ""});
        data.add(new String[]{"3", "Nguyễn Bá Cường", "YES", "YES", "YES", "NO", "NO", "NO", "add to this sprint"});
        data.add(new String[]{"4", "Vũ Công Tịnh", "NO", "NO", "NO", "YES", "YES", "YES", "???"});
        data.add(new String[]{"5", "Phạm Trọng Khang", "YES", "NO", "YES", "NO", "NO", "NO", ""});
        data.add(new String[]{"6", "Mai Văn Tài", "YES", "NO", "YES", "NO", "NO", "NO", "huiguy"});
        
        WritableWorkbook workbook;
        try {
            workbook = Workbook.createWorkbook(new File(fileName));
            WritableSheet sheet = workbook.createSheet("Report", 0);
            
            int rowBegin = 0;
            int colBegin = 0;
            // write header
            for (String headerName : header) {
                sheet.addCell(new Label(colBegin, rowBegin, headerName));
                colBegin++;
            }
            colBegin = 0;
            rowBegin = 1;
            // write data
            for (String[] rowData : data) {
                for (String colData : rowData) {
                    sheet.addCell(new Label(colBegin, rowBegin, colData));
                    colBegin++;
                }
                colBegin = 0;
                rowBegin++;
            }
            
            workbook.write();
            workbook.close();
        } catch (Exception e) {
            System.err.println("Cannot save");
        }
    }
    
    public static class FileTypeFilter extends FileFilter {
        private final String extension;
        private final String description;

        public FileTypeFilter(String extension, String description) {
            this.extension = extension;
            this.description = description;
        }

        @Override
        public boolean accept(File file) {
            if (file.isDirectory()) {
                return true;
            }
            return file.getName().endsWith(extension);
        }

        @Override
        public String getDescription() {
            return description + String.format(" (*%s)", extension);
        }
        
        public String getExtension() {
            return extension;
        }
    }
}