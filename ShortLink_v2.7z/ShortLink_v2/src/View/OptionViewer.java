package View;
//@author Duong Nguyen
import Control.OptionControl;
import Control.showPanelDialog;

public class OptionViewer extends javax.swing.JPanel {
    private final OptionControl OptionControl;
    private final showPanelDialog showDG;
    
    public OptionViewer(showPanelDialog showDG) {
        initComponents();
        this.showDG=showDG;
        OptionControl=new OptionControl();
        buildGUI();
    }
    
    public final void buildGUI(){
        String value=OptionControl.readRegistry();
        if(value!=null) jcbStartup.setSelected(true);
        else jcbStartup.setSelected(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jbtDongy = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jcbStartup = new javax.swing.JCheckBox();

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Hủy");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jbtDongy.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jbtDongy.setText("Đồng ý");
        jbtDongy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtDongyActionPerformed(evt);
            }
        });

        jcbStartup.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jcbStartup.setText("  Khởi động cùng Windows?");
        jcbStartup.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jcbStartup.setInheritsPopupMenu(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
            .addComponent(jcbStartup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(jbtDongy)
                .addGap(28, 28, 28)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jcbStartup)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jbtDongy)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        showDG.Hidden();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jbtDongyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtDongyActionPerformed
        if(jcbStartup.isSelected()){
            OptionControl.writeRegistry();
        } else{
            OptionControl.deleteRegistry();
        }
        showDG.Hidden();
    }//GEN-LAST:event_jbtDongyActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton jbtDongy;
    private javax.swing.JCheckBox jcbStartup;
    // End of variables declaration//GEN-END:variables
}