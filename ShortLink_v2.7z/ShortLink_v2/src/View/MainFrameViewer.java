package View;
//@author Duong Nguyen
import Control.MainFrameControl;
import Control.TableAbstractControl;
import Control.showPanelDialog;
import java.awt.*;
import javax.swing.*;

public class MainFrameViewer extends javax.swing.JFrame {
    private JLabel Rlabel;
    private final MainFrameControl MainFrameControl;
    private final TableAbstractControl TableAbstractControl;
    public MainFrameViewer() {
        initComponents();
        MainFrameControl=new MainFrameControl(this);
        TableAbstractControl=new TableAbstractControl(jTable1, this);
        BuildGUI();
    }
    
    public final void BuildGUI(){
        MainFrameControl.FrameDecorate();
        MainFrameControl.TableDecorate(jTable1,jScrollPane1);
        TableAbstractControl.createTable();
        TableAbstractControl.MouseMotionEvent();
        this.pack();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jlbOption = new javax.swing.JLabel();
        jlbClose = new javax.swing.JLabel();
        jlbAbout = new javax.swing.JLabel();
        jlbFeedback = new javax.swing.JLabel();
        jlbTitle = new javax.swing.JLabel();

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/delete.png"))); // NOI18N
        jMenuItem1.setText("Delete");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTable1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTable1MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jlbOption.setBackground(new java.awt.Color(255, 255, 255));
        jlbOption.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlbOption.setForeground(new java.awt.Color(255, 255, 255));
        jlbOption.setText("Option");
        jlbOption.setToolTipText("Tùy chọn");
        jlbOption.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlbOption.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbOptionMouseClicked(evt);
            }
        });

        jlbClose.setBackground(new java.awt.Color(255, 255, 255));
        jlbClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        jlbClose.setToolTipText("Thoát");
        jlbClose.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlbClose.setOpaque(true);
        jlbClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbCloseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jlbCloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jlbCloseMouseExited(evt);
            }
        });

        jlbAbout.setBackground(new java.awt.Color(255, 255, 255));
        jlbAbout.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlbAbout.setForeground(new java.awt.Color(255, 255, 255));
        jlbAbout.setText("About");
        jlbAbout.setToolTipText("Thông tin");
        jlbAbout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlbAbout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbAboutMouseClicked(evt);
            }
        });

        jlbFeedback.setBackground(new java.awt.Color(255, 255, 255));
        jlbFeedback.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlbFeedback.setForeground(new java.awt.Color(255, 255, 255));
        jlbFeedback.setText("Feedback");
        jlbFeedback.setToolTipText("Phản hồi");
        jlbFeedback.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlbFeedback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbFeedbackMouseClicked(evt);
            }
        });

        jlbTitle.setBackground(new java.awt.Color(255, 255, 255));
        jlbTitle.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jlbTitle.setForeground(new java.awt.Color(255, 255, 255));
        jlbTitle.setText("Short Link v2.0 DN");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jlbTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlbOption)
                .addGap(10, 10, 10)
                .addComponent(jlbFeedback)
                .addGap(10, 10, 10)
                .addComponent(jlbAbout)
                .addGap(8, 8, 8)
                .addComponent(jlbClose))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jlbTitle)
                    .addComponent(jlbOption)
                    .addComponent(jlbFeedback)
                    .addComponent(jlbAbout)
                    .addComponent(jlbClose))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 475, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlbOptionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbOptionMouseClicked
        showPanelDialog showDG=new showPanelDialog(this);
        OptionViewer option=new OptionViewer(showDG);
        showDG.showPanel("Thiết lập tùy chọn", option, 300, 120);
    }//GEN-LAST:event_jlbOptionMouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if(SwingUtilities.isLeftMouseButton(evt)){
            int row=jTable1.rowAtPoint(evt.getPoint());
            int column=jTable1.columnAtPoint(evt.getPoint());
            TableAbstractControl.MouseClicked(row, column);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseExited
        TableAbstractControl.setCellBackground();
        jTable1.repaint();
    }//GEN-LAST:event_jTable1MouseExited

    private void jTable1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseEntered
        int row=jTable1.rowAtPoint(evt.getPoint());
        int column=jTable1.columnAtPoint(evt.getPoint());
        TableAbstractControl.MouseEntered(row, column);
    }//GEN-LAST:event_jTable1MouseEntered

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        if(SwingUtilities.isRightMouseButton(evt)){
            int row=jTable1.rowAtPoint(evt.getPoint());
            int column=jTable1.columnAtPoint(evt.getPoint());
            Rlabel=(JLabel) jTable1.getValueAt(row, column);
            if(Rlabel.getToolTipText()==null||Rlabel.getToolTipText().equals("Add New")) return;
            jPopupMenu1.show(jTable1, evt.getX(),evt.getY());
        }
    }//GEN-LAST:event_jTable1MouseReleased

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        TableAbstractControl.Delete(Rlabel, this);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jlbCloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbCloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jlbCloseMouseClicked

    private void jlbCloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbCloseMouseEntered
        ImageIcon icon=new ImageIcon(this.getClass().getResource("/"+"image/close_light.png"));
        jlbClose.setIcon(icon);
        jlbClose.setBackground(Color.decode("#e81123"));
    }//GEN-LAST:event_jlbCloseMouseEntered

    private void jlbCloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbCloseMouseExited
        ImageIcon icon=new ImageIcon(this.getClass().getResource("/"+"image/close.png"));
        jlbClose.setIcon(icon);
        jlbClose.setBackground(jTable1.getBackground());
    }//GEN-LAST:event_jlbCloseMouseExited

    private void jlbAboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbAboutMouseClicked
        JOptionPane.showMessageDialog(this, "Author: Dương Nguyên","Short Link v2.0",1);
    }//GEN-LAST:event_jlbAboutMouseClicked

    private void jlbFeedbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbFeedbackMouseClicked
        try{
            TableAbstractControl.OpenURL("//www.facebook.com/nguyen08147");
        } catch(Exception e){}
    }//GEN-LAST:event_jlbFeedbackMouseClicked
    
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
        }
        //</editor-fold>
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public synchronized void run() {
                new MainFrameViewer().setVisible(true);
            }
        });*/
        new MainFrameViewer().setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel jlbAbout;
    private javax.swing.JLabel jlbClose;
    private javax.swing.JLabel jlbFeedback;
    private javax.swing.JLabel jlbOption;
    private javax.swing.JLabel jlbTitle;
    // End of variables declaration//GEN-END:variables
}