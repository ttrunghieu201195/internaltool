package Model;
//@author Duong Nguyen
import Data.WinRegistry;

public class OptionModel {
    public OptionModel(){
        
    }
    
    public String readRegistry(String key, String valueName){
        try{
            String value = WinRegistry.readString (
            WinRegistry.HKEY_CURRENT_USER, key, valueName);
            return value;
        } catch(Exception e){return null;}
    }
    
    public void writeRegistry(String key, String valueName, String name){
        try{
            String value = System.getProperty("user.dir")+"\\"+valueName;
            WinRegistry.writeStringValue(WinRegistry.HKEY_CURRENT_USER, 
                key, name, value);
        } catch(Exception e){}
    }
    
    public void deleteRegistry(String key, String name){
        try{
            WinRegistry.deleteValue(WinRegistry.HKEY_CURRENT_USER, 
                key, name);
        } catch(Exception e){}
    }
    
}