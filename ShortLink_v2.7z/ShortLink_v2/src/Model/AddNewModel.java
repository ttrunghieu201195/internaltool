package Model;
//@author Duong Nguyen
import View.AddNewViewer;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class AddNewModel {
    private final AddNewViewer AddNewViewer;
    public AddNewModel(AddNewViewer AddNewViewer){
        this.AddNewViewer=AddNewViewer;
    }
    
    public String getImage(){
        String extension = null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose image");
        
        FileFilter xlsFilter = new FileTypeFilter(".png", "PNG");
        fileChooser.addChoosableFileFilter(xlsFilter);
        xlsFilter = new FileTypeFilter(".jpg", "JPEG");
        fileChooser.addChoosableFileFilter(xlsFilter);
        
        fileChooser.setAcceptAllFileFilterUsed(true);
        int userSelection = fileChooser.showOpenDialog(AddNewViewer);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            extension=fileToSave.getAbsolutePath();
        }
        return extension;
    }
    
    // <editor-fold defaultstate="collapsed" desc="FileTypeFilter Class">
    public class FileTypeFilter extends javax.swing.filechooser.FileFilter {
        private final String extension;
        private final String description;

        public FileTypeFilter(String extension, String description) {
            this.extension = extension;
            this.description = description;
        }
        
        @Override
        public boolean accept(File file) {
            if (file.isDirectory()) {
                return true;
            }
            return file.getName().endsWith(extension);
        }

        @Override
        public String getDescription() {
            return description + String.format(" (*%s)", extension);
        }
    }
    //</editor-fold>
}