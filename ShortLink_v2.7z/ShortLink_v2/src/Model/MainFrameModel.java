package Model;
//@author Duong Nguyen
import Data.MainFrameData;
import java.awt.*;
import javax.swing.*;

public class MainFrameModel {
    private final JFrame frame;
    private final MainFrameData MainFrameData;
    public MainFrameModel(JFrame frame){
        this.frame=frame;
        MainFrameData=new MainFrameData(frame);
    }
    
    public void FrameDecorate(){
        frame.setLocation(MainFrameData.getX(), MainFrameData.getY());
        frame.dispose();
        frame.setType(JFrame.Type.UTILITY);
        frame.setUndecorated(true);      
        frame.setVisible(true);
        FrameDragListener frameDrag=new FrameDragListener(frame);
        frame.addMouseListener(frameDrag);
        frame.addMouseMotionListener(frameDrag);
        frame.getContentPane().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        frame.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
    }
    
    public void TableDecorate(JTable jTable, JScrollPane jScrollPane){
        jTable.setRowSelectionAllowed(false);
        jTable.setShowGrid(false);
        jTable.setTableHeader(null);
        jTable.setBorder(null);
        jTable.setOpaque(false);
        
        jScrollPane.getColumnHeader().setVisible(false);
        jScrollPane.setBorder(null);
        jScrollPane.getViewport().setBackground(Color.WHITE);
        jScrollPane.setOpaque(false);
        jScrollPane.getViewport().setOpaque(false);
    }
    
}