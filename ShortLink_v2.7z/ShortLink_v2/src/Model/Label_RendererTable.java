package Model;
//@author Duong Nguyen
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

public class Label_RendererTable extends DefaultTableCellRenderer{
    public Label_RendererTable(){
        
    }
    //Abstract Method
    @Override
    public Component getTableCellRendererComponent(JTable jtable, Object valueObject, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel label=(JLabel) valueObject;
        setCenterIconLabel(label);
        return label;
    }
    
    public void setCenterIconLabel(JLabel lb){
        lb.setVerticalTextPosition(AbstractButton.BOTTOM);
        lb.setHorizontalTextPosition(AbstractButton.CENTER);
        lb.setHorizontalAlignment(JLabel.CENTER);
    }
}