package Model;
//@author Duong Nguyen
import Data.GetExcelData;
import Data.TableAbstractValue;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import javax.swing.*;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class TableAbstractModel {
    private final JTable jTable;
    private final GetExcelData GetExcelData;
    private Sheet sheet;
    public TableAbstractModel(JTable jTable){
        this.jTable=jTable;
        GetExcelData=new GetExcelData();
    }
    
    //<editor-fold defaultstate="collapsed" desc=" createTable ">
    public void createTable(){
        String header[]=new String[]{"","","",""};
        ArrayList<Object[]> data=new ArrayList<>();
        Workbook workbook=GetExcelData.getWorkbook();
        
        sheet = workbook.getSheet(0);
        int rows = sheet.getRows()-1;
        //int cols = sheet.getColumns();
        JLabel label[];
        int div=rows/4; int mod=rows%4; 
        int row=1;
        for (int i=0; i<div; i++) {
            label=new JLabel[4];
            for(int j=0;j<4;j++){
                label[j]=new JLabel();
                label[j]=setLabel(label[j], row);
                row++;
            }
            data.add(new Object[]{
                label[0],label[1],label[2],label[3]
            });
        }
        
        JLabel addLB=new JLabel();
            addLB.setText("Add New");
            addLB.setFont(new Font("Tahoma",Font.BOLD,11));
            addLB.setForeground(Color.WHITE);
            addLB.setToolTipText("Add New");
            ImageIcon icon=new ImageIcon(this.getClass().getResource("/"+"image/add.png"));
            addLB.setIcon(icon);
            //if mod
            switch(mod){
                case 1:
                    JLabel jLabel=new JLabel();
                    jLabel=setLabel(jLabel, row);
                    data.add(new Object[]{
                        jLabel,addLB,new JLabel(),new JLabel()
                    });
                    break;
                case 2:
                    label=new JLabel[2];
                    for(int i=0;i<2;i++){
                        label[i]=new JLabel();
                        label[i]=setLabel(label[i], row);
                        row++;
                    }
                    data.add(new Object[]{
                        label[0],label[1],addLB,new JLabel()
                    });
                    break;
                case 3:
                    label=new JLabel[3];
                    for(int i=0;i<3;i++){
                        label[i]=new JLabel();
                        label[i]=setLabel(label[i], row);
                        row++;
                    }
                    data.add(new Object[]{
                        label[0],label[1],label[2],addLB
                    });
                    break;
                default:
                    data.add(new Object[]{
                        addLB,new JLabel(),new JLabel(),new JLabel()
                    });
                    break;
            }
            workbook.close();
        TableAbstractValue myTable=new TableAbstractValue(header, data);
        jTable.setModel(myTable);
        jTable.setDefaultRenderer(String.class, new Label_RendererTable());
        jTable.setRowHeight(70);
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc=" setLabel ">
    public JLabel setLabel(JLabel label, int row){
        label=new JLabel();
        label.setFont(new Font("Tahoma",Font.BOLD,11));
        label.setForeground(Color.WHITE);
        Cell cell = sheet.getCell(0,row);
        label.setToolTipText(cell.getContents());
        label.setText(cell.getContents());
        //set Icon
        cell = sheet.getCell(2,row);
        String url=cell.getContents();
        ImageIcon icon;
        if(url.startsWith("/")){
            icon=new ImageIcon(this.getClass().getResource(url));
        } else{
            icon=new ImageIcon(url);
        }
        ImageIcon tmp=new ImageIcon((icon.getImage()).getScaledInstance(50, 50, Image.SCALE_DEFAULT));
        label.setIcon(tmp);
        return label;
    }
    //</editor-fold>
    
    public String getURL(String name){
        return GetExcelData.getURL(name);
    }
    
    //<editor-fold defaultstate="collapsed" desc=" Delete ">
    public int Delete(String name){
        WritableWorkbook writeWorkbook;
        try {
            Workbook workbook=GetExcelData.getWorkbook();
            String file=System.getProperty("user.dir");
            //FileOutputStream os=new FileOutputStream(file);
            writeWorkbook = Workbook.createWorkbook(new File(file+"\\data"), workbook);
            
            WritableSheet sheetc = writeWorkbook.getSheet(0);
            int rows = sheetc.getRows();
            for(int i=1;i<rows;i++){
                Cell cell = sheetc.getCell(0,i);
                if(name.equals(cell.getContents())){
                    sheetc.removeRow(i);
                    break;
                }
            }
            writeWorkbook.write();
            writeWorkbook.close();
        } catch (Exception ex) {
            return 0;
        }
        return 1;
    }
    //</editor-fold>
}
