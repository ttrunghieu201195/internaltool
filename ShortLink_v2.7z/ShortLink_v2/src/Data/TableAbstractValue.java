package Data;
//@author Duong Nguyen
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class TableAbstractValue extends AbstractTableModel{
    private String columnName[];
    private ArrayList<Object[]> data=new ArrayList<>();
    public int isCellEditable=-1; public int tab=0;
    public TableAbstractValue(){
    }
    public TableAbstractValue(String columnName[], ArrayList<Object[]> data){
        this.columnName=columnName;
        this.data=data;
    }
    
    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnName.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data.get(rowIndex)[columnIndex];
    }
    
    @Override
    public String getColumnName(int column){
        return columnName[column];
    }
    
    @Override
    public Class getColumnClass(int column){
        Class dataType=super.getColumnClass(column);
        dataType=String.class;
        return dataType;
    }
    
    @Override
    public boolean isCellEditable(int row, int column){
        if(isCellEditable==1) return true;
        /*
        else if(tab==4){
            if(isCellEditable==0||column!=1) return false;
        }
        return true;*/
        return false;
    }
    
    @Override
    public void setValueAt(Object value, int row, int column){
        data.get(row)[column] = value;
        fireTableCellUpdated(row, column);
        //data[row][column] = value;
    }
}