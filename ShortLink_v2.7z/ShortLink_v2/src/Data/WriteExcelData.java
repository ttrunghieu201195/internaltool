package Data;
//@author Duong Nguyen
import java.io.File;
import javax.swing.JOptionPane;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class WriteExcelData {
    public WriteExcelData(){
        
    }
    public void openAndWriteFileExcel(String name, String url, String icon) {
        Workbook workbook;
        WritableWorkbook writeWorkbook;
        try {
            File file=new File(System.getProperty("user.dir")+"\\data");
            workbook = Workbook.getWorkbook(file);
            //FileOutputStream os=new FileOutputStream(file);
            writeWorkbook = Workbook.createWorkbook(file, workbook);
            
            WritableSheet sheet = writeWorkbook.getSheet(0);
            int row=sheet.getRows();
            sheet.addCell(new Label(0, row, name));
            sheet.addCell(new Label(1, row, url));
            sheet.addCell(new Label(2, row, icon));
            
            writeWorkbook.write();
            writeWorkbook.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Không thể thêm!","Lỗi",0);
        }
    }
}