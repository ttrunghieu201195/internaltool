package Data;
//@author Duong Nguyen
import java.awt.*;
import javax.swing.JFrame;

public class MainFrameData {
    private final int x,y;
    public MainFrameData(JFrame jFrame){
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
        Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
        x=(int) rect.getMaxX() - (jFrame.getWidth()-15);
        y=0;
        //y = (int) rect.getMaxY() - (this.getHeight()+10);
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
    
}