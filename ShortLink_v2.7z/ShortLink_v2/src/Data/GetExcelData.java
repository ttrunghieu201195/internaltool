package Data;
//@author Duong Nguyen
import java.io.*;
import javax.swing.*;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class GetExcelData {
    public GetExcelData(){
        
    }
    
    public Workbook getWorkbook(){
        Workbook workbook;
        try{
            File file=new File(System.getProperty("user.dir")+"\\data");
            workbook = Workbook.getWorkbook(file);
            return workbook;
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"Không tìm thấy dữ liệu","Lỗi",0);
            System.exit(0);
            return null;
        }
    }
    
    public String getURL(String name){
        String url = null;
        Workbook workbook=getWorkbook();
        Sheet sheet = workbook.getSheet(0);
        int rows = sheet.getRows();
        for(int i=1;i<rows;i++){
            Cell cell = sheet.getCell(0,i);
            if(name.equals(cell.getContents())){
                cell = sheet.getCell(1,i);
                url=cell.getContents();
                break;
            }
        }
        workbook.close();
        return url;
    }
}
