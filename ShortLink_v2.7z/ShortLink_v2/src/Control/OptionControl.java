package Control;
//@author Duong Nguyen
import Model.OptionModel;
public class OptionControl {
    private final OptionModel OptionModel;
    private final String key;
    public OptionControl(){
        key="Software\\Microsoft\\Windows\\CurrentVersion\\Run";
        OptionModel=new OptionModel();
    }
    
    public String readRegistry(){
        return OptionModel.readRegistry(key, "ShortLink_Startup");
    }
    
    public void writeRegistry(){
        OptionModel.writeRegistry(key, "ShortLink.exe", "ShortLink_Startup");
    }
    
    public void deleteRegistry(){
        OptionModel.deleteRegistry(key, "ShortLink_Startup");
    }
}