package Control;
//@author Duong Nguyen
import Model.MainFrameModel;
import javax.swing.*;

public class MainFrameControl {
    private final MainFrameModel MainFrameModel;
    public MainFrameControl(JFrame frame){
        MainFrameModel=new MainFrameModel(frame);
    }
    
    public void FrameDecorate(){
        MainFrameModel.FrameDecorate();
    }
    
    public void TableDecorate(JTable jTable, JScrollPane jScrollPane){
        MainFrameModel.TableDecorate(jTable,jScrollPane);
    }
}
