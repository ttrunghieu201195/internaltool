package Control;
//@author Duong Nguyen
import java.awt.Component;
import javax.swing.*;

public class showPanelDialog {
    private final JFrame frame;
    private JDialog dialog;
    public showPanelDialog(JFrame frame){
        this.frame=frame;
    }
    public void showPanel(String title, Component cp, int width, int height){
        dialog=new JDialog(frame ,title, true);
        dialog.add(cp);
        dialog.setSize(width,height);
        dialog.setLocationRelativeTo(frame);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }
    public void Hidden(){
        this.dialog.dispose(); //ẩn panel đi
    }
}