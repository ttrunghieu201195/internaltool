package Control;
//@author Duong Nguyen
import Data.WriteExcelData;
import Model.AddNewModel;
import View.AddNewViewer;

public class AddNewControl {
    private final AddNewViewer AddNewViewer;
    private final TableAbstractControl TableAbstractControl;
    public AddNewControl(AddNewViewer AddNewViewer, TableAbstractControl TableAbstractControl){
        this.AddNewViewer=AddNewViewer;
        this.TableAbstractControl=TableAbstractControl;
    }
    
    public void addNew(String name, String url, String icon){
        WriteExcelData excel=new WriteExcelData();
        excel.openAndWriteFileExcel(name, url, icon);
        TableAbstractControl.createTable();
        TableAbstractControl.setCellBackground();
    }
    
    public String getURLImage(){
        AddNewModel AddNewModel=new AddNewModel(AddNewViewer);
        return AddNewModel.getImage();
    }
}