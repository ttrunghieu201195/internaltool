package Control;
//@author Duong Nguyen
import Model.TableAbstractModel;
import View.AddNewViewer;
import View.MainFrameViewer;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.net.URI;
import javax.swing.*;

public class TableAbstractControl {
    private final JTable jTable;
    private TableAbstractModel TableAbstractModel;
    private final MainFrameViewer MainFrameViewer;
    public TableAbstractControl(JTable jTable, MainFrameViewer MainFrameViewer){
        this.jTable=jTable;
        this.MainFrameViewer=MainFrameViewer;
    }
    
    public void createTable(){
        TableAbstractModel=new TableAbstractModel(jTable);
        TableAbstractModel.createTable();
    }
    
    public void setCellBackground(){
        for(int i=0;i<jTable.getRowCount();i++){
            for(int j=0;j<jTable.getColumnCount();j++){
                JLabel label=(JLabel) jTable.getValueAt(i, j);
                label.setOpaque(false);
                //label.setBackground(Color.WHITE);
            }
        }
    }
    
    //<editor-fold defaultstate="collapsed" desc=" MouseEvent ">
    public void MouseMotionEvent(){
        jTable.addMouseMotionListener(new MouseMotionAdapter() {
            int oldRow=-1,oldCol=-1;
            @Override
            public void mouseMoved(MouseEvent e){
                jTable.repaint();
                int row=jTable.rowAtPoint(e.getPoint());
                int column=jTable.columnAtPoint(e.getPoint());
                if(row==oldRow && column==oldCol) return;
                JLabel label=(JLabel) jTable.getValueAt(row, column);
                if(label.getToolTipText()==null) return;
                label.setOpaque(true);
                label.setBackground(Color.decode("#87a4c3"));
                try{
                    label=(JLabel) jTable.getValueAt(oldRow, oldCol);
                    //label.setBackground(Color.WHITE);
                    label.setOpaque(false);
                } catch(Exception ex){}
                oldRow=row; oldCol=column;
            }
        });
    }
    
    public void MouseEntered(int row, int column){
        JLabel label=(JLabel) jTable.getValueAt(row, column);
        if(label.getToolTipText()==null) return;
        label.setOpaque(true);
        label.setBackground(Color.decode("#87a4c3"));
    }
    
    public void MouseClicked(int row, int column){
        JLabel label=(JLabel) jTable.getValueAt(row, column);
        if(label.getToolTipText().equals("Add New")){
            showPanelDialog showDG=new showPanelDialog(MainFrameViewer);
            AddNewViewer AddNewViewer=new AddNewViewer(showDG, this);
            showDG.showPanel("Thêm trang web", AddNewViewer, 460, 230);
        } else{
            OpenURL(label.getToolTipText());
        }
    }
    //</editor-fold>
    
    public void OpenURL(String name){
        String url;
        if(name.startsWith("//")) url=name.replace("//", "");
        else {
            url=TableAbstractModel.getURL(name);}
        if(Desktop.isDesktopSupported()){
            try{
                url=url.replace("https://", "");
                Desktop.getDesktop().browse(new URI("https://"+url));
            } catch(Exception e){
                JOptionPane.showMessageDialog(null,"Không tìm thấy trang: "+url,"Lỗi",0);
            }
        }
    }
    
    public void Delete(JLabel label, MainFrameViewer MainFrameViewer){
        int i=JOptionPane.showConfirmDialog(MainFrameViewer, 
                "Xóa trang web: "+label.getToolTipText()+"?", "Thông báo", JOptionPane.YES_NO_OPTION);
        if(i==JOptionPane.YES_OPTION){
            if(TableAbstractModel.Delete(label.getToolTipText())==0)
                JOptionPane.showMessageDialog(null,"Không thể xóa!","Lỗi",0);
            else{
                TableAbstractModel.createTable();
                setCellBackground();
            }
        }
    }
}