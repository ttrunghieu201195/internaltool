﻿namespace demo
{
    partial class CreateDeliverableFolder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateDeliverableFolder));
            this.FooterPanel = new System.Windows.Forms.Panel();
            this.lbRightFotter = new System.Windows.Forms.Label();
            this.RightPanelFooter = new System.Windows.Forms.Panel();
            this.lbFooter = new System.Windows.Forms.Label();
            this.line = new System.Windows.Forms.Panel();
            this.HeaderPanel = new System.Windows.Forms.TableLayoutPanel();
            this.PanelRow1 = new System.Windows.Forms.Panel();
            this.btBrowseFolder = new System.Windows.Forms.Button();
            this.btBrowseExFile = new System.Windows.Forms.Button();
            this.tbSelectParentFolder = new System.Windows.Forms.TextBox();
            this.lbSelectParentFolder = new System.Windows.Forms.Label();
            this.tbSelectFile = new System.Windows.Forms.TextBox();
            this.lbSelectFile = new System.Windows.Forms.Label();
            this.PanelRow3 = new System.Windows.Forms.Panel();
            this.btLoad = new System.Windows.Forms.Button();
            this.btApply = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.gbCenter = new System.Windows.Forms.GroupBox();
            this.pnLeftCenter = new System.Windows.Forms.Panel();
            this.pnRightCenter = new System.Windows.Forms.Panel();
            this.gbNote = new System.Windows.Forms.GroupBox();
            this.rtbNote = new System.Windows.Forms.RichTextBox();
            this.gbExample = new System.Windows.Forms.GroupBox();
            this.treeView = new System.Windows.Forms.TreeView();
            this.FooterPanel.SuspendLayout();
            this.HeaderPanel.SuspendLayout();
            this.PanelRow1.SuspendLayout();
            this.PanelRow3.SuspendLayout();
            this.gbCenter.SuspendLayout();
            this.pnLeftCenter.SuspendLayout();
            this.pnRightCenter.SuspendLayout();
            this.gbNote.SuspendLayout();
            this.gbExample.SuspendLayout();
            this.SuspendLayout();
            // 
            // FooterPanel
            // 
            this.FooterPanel.BackColor = System.Drawing.Color.White;
            this.FooterPanel.Controls.Add(this.lbRightFotter);
            this.FooterPanel.Controls.Add(this.RightPanelFooter);
            this.FooterPanel.Controls.Add(this.lbFooter);
            this.FooterPanel.Controls.Add(this.line);
            this.FooterPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.FooterPanel.Location = new System.Drawing.Point(0, 567);
            this.FooterPanel.Name = "FooterPanel";
            this.FooterPanel.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.FooterPanel.Size = new System.Drawing.Size(1028, 43);
            this.FooterPanel.TabIndex = 3;
            // 
            // lbRightFotter
            // 
            this.lbRightFotter.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbRightFotter.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRightFotter.ForeColor = System.Drawing.Color.Gray;
            this.lbRightFotter.Location = new System.Drawing.Point(703, 19);
            this.lbRightFotter.Name = "lbRightFotter";
            this.lbRightFotter.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.lbRightFotter.Size = new System.Drawing.Size(195, 24);
            this.lbRightFotter.TabIndex = 3;
            this.lbRightFotter.Text = "BIG IDEAS FOR EVERY SPACE";
            // 
            // RightPanelFooter
            // 
            this.RightPanelFooter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RightPanelFooter.BackgroundImage")));
            this.RightPanelFooter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RightPanelFooter.Dock = System.Windows.Forms.DockStyle.Right;
            this.RightPanelFooter.Location = new System.Drawing.Point(898, 19);
            this.RightPanelFooter.Name = "RightPanelFooter";
            this.RightPanelFooter.Size = new System.Drawing.Size(100, 24);
            this.RightPanelFooter.TabIndex = 2;
            // 
            // lbFooter
            // 
            this.lbFooter.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbFooter.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFooter.ForeColor = System.Drawing.Color.Blue;
            this.lbFooter.Location = new System.Drawing.Point(30, 19);
            this.lbFooter.Name = "lbFooter";
            this.lbFooter.Padding = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.lbFooter.Size = new System.Drawing.Size(141, 24);
            this.lbFooter.TabIndex = 1;
            this.lbFooter.Text = "Release: Aug 30, 2017";
            // 
            // line
            // 
            this.line.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("line.BackgroundImage")));
            this.line.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.line.Dock = System.Windows.Forms.DockStyle.Top;
            this.line.Location = new System.Drawing.Point(30, 0);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(968, 19);
            this.line.TabIndex = 0;
            // 
            // HeaderPanel
            // 
            this.HeaderPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HeaderPanel.BackColor = System.Drawing.Color.White;
            this.HeaderPanel.ColumnCount = 1;
            this.HeaderPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.HeaderPanel.Controls.Add(this.PanelRow1, 0, 0);
            this.HeaderPanel.Controls.Add(this.PanelRow3, 0, 2);
            this.HeaderPanel.Controls.Add(this.gbCenter, 0, 1);
            this.HeaderPanel.Location = new System.Drawing.Point(0, 0);
            this.HeaderPanel.Name = "HeaderPanel";
            this.HeaderPanel.RowCount = 3;
            this.HeaderPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.HeaderPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.HeaderPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.HeaderPanel.Size = new System.Drawing.Size(1028, 571);
            this.HeaderPanel.TabIndex = 4;
            // 
            // PanelRow1
            // 
            this.PanelRow1.Controls.Add(this.btBrowseFolder);
            this.PanelRow1.Controls.Add(this.btBrowseExFile);
            this.PanelRow1.Controls.Add(this.tbSelectParentFolder);
            this.PanelRow1.Controls.Add(this.lbSelectParentFolder);
            this.PanelRow1.Controls.Add(this.tbSelectFile);
            this.PanelRow1.Controls.Add(this.lbSelectFile);
            this.PanelRow1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelRow1.Location = new System.Drawing.Point(3, 3);
            this.PanelRow1.Name = "PanelRow1";
            this.PanelRow1.Size = new System.Drawing.Size(1022, 144);
            this.PanelRow1.TabIndex = 0;
            // 
            // btBrowseFolder
            // 
            this.btBrowseFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btBrowseFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btBrowseFolder.Location = new System.Drawing.Point(921, 94);
            this.btBrowseFolder.Name = "btBrowseFolder";
            this.btBrowseFolder.Size = new System.Drawing.Size(74, 28);
            this.btBrowseFolder.TabIndex = 5;
            this.btBrowseFolder.Text = "Browse";
            this.btBrowseFolder.UseVisualStyleBackColor = true;
            this.btBrowseFolder.Click += new System.EventHandler(this.btBrowseFolder_Click);
            // 
            // btBrowseExFile
            // 
            this.btBrowseExFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btBrowseExFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btBrowseExFile.Location = new System.Drawing.Point(921, 21);
            this.btBrowseExFile.Name = "btBrowseExFile";
            this.btBrowseExFile.Size = new System.Drawing.Size(74, 28);
            this.btBrowseExFile.TabIndex = 4;
            this.btBrowseExFile.Text = "Browse";
            this.btBrowseExFile.UseVisualStyleBackColor = true;
            this.btBrowseExFile.Click += new System.EventHandler(this.btBrowseExFile_Click);
            // 
            // tbSelectParentFolder
            // 
            this.tbSelectParentFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSelectParentFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSelectParentFolder.Location = new System.Drawing.Point(404, 96);
            this.tbSelectParentFolder.Name = "tbSelectParentFolder";
            this.tbSelectParentFolder.Size = new System.Drawing.Size(498, 26);
            this.tbSelectParentFolder.TabIndex = 3;
            // 
            // lbSelectParentFolder
            // 
            this.lbSelectParentFolder.AutoSize = true;
            this.lbSelectParentFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSelectParentFolder.Location = new System.Drawing.Point(23, 99);
            this.lbSelectParentFolder.Name = "lbSelectParentFolder";
            this.lbSelectParentFolder.Size = new System.Drawing.Size(299, 20);
            this.lbSelectParentFolder.TabIndex = 2;
            this.lbSelectParentFolder.Text = "Select parent folder for Deliverable: ";
            // 
            // tbSelectFile
            // 
            this.tbSelectFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSelectFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSelectFile.Location = new System.Drawing.Point(404, 23);
            this.tbSelectFile.Name = "tbSelectFile";
            this.tbSelectFile.Size = new System.Drawing.Size(498, 26);
            this.tbSelectFile.TabIndex = 1;
            // 
            // lbSelectFile
            // 
            this.lbSelectFile.AutoSize = true;
            this.lbSelectFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSelectFile.Location = new System.Drawing.Point(23, 26);
            this.lbSelectFile.Name = "lbSelectFile";
            this.lbSelectFile.Size = new System.Drawing.Size(375, 20);
            this.lbSelectFile.TabIndex = 0;
            this.lbSelectFile.Text = "Select the purchase specification (Excel file): ";
            // 
            // PanelRow3
            // 
            this.PanelRow3.Controls.Add(this.btLoad);
            this.PanelRow3.Controls.Add(this.btApply);
            this.PanelRow3.Controls.Add(this.btCancel);
            this.PanelRow3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelRow3.Location = new System.Drawing.Point(3, 524);
            this.PanelRow3.Name = "PanelRow3";
            this.PanelRow3.Size = new System.Drawing.Size(1022, 44);
            this.PanelRow3.TabIndex = 1;
            // 
            // btLoad
            // 
            this.btLoad.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLoad.Location = new System.Drawing.Point(665, 9);
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(128, 28);
            this.btLoad.TabIndex = 8;
            this.btLoad.Text = "Load to preview";
            this.btLoad.UseVisualStyleBackColor = true;
            this.btLoad.Click += new System.EventHandler(this.btLoad_Click);
            // 
            // btApply
            // 
            this.btApply.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btApply.Enabled = false;
            this.btApply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btApply.Location = new System.Drawing.Point(821, 9);
            this.btApply.Name = "btApply";
            this.btApply.Size = new System.Drawing.Size(74, 28);
            this.btApply.TabIndex = 7;
            this.btApply.Text = "Apply";
            this.btApply.UseVisualStyleBackColor = true;
            this.btApply.Click += new System.EventHandler(this.btApply_Click);
            // 
            // btCancel
            // 
            this.btCancel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.Location = new System.Drawing.Point(921, 9);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(74, 28);
            this.btCancel.TabIndex = 6;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // gbCenter
            // 
            this.gbCenter.Controls.Add(this.pnLeftCenter);
            this.gbCenter.Controls.Add(this.pnRightCenter);
            this.gbCenter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbCenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCenter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.gbCenter.Location = new System.Drawing.Point(3, 153);
            this.gbCenter.Name = "gbCenter";
            this.gbCenter.Size = new System.Drawing.Size(1022, 365);
            this.gbCenter.TabIndex = 2;
            this.gbCenter.TabStop = false;
            this.gbCenter.Text = "Preview";
            // 
            // pnLeftCenter
            // 
            this.pnLeftCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnLeftCenter.Controls.Add(this.gbExample);
            this.pnLeftCenter.Location = new System.Drawing.Point(0, 25);
            this.pnLeftCenter.Name = "pnLeftCenter";
            this.pnLeftCenter.Padding = new System.Windows.Forms.Padding(15, 8, 15, 15);
            this.pnLeftCenter.Size = new System.Drawing.Size(638, 337);
            this.pnLeftCenter.TabIndex = 1;
            // 
            // pnRightCenter
            // 
            this.pnRightCenter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnRightCenter.Controls.Add(this.gbNote);
            this.pnRightCenter.Location = new System.Drawing.Point(638, 25);
            this.pnRightCenter.Name = "pnRightCenter";
            this.pnRightCenter.Padding = new System.Windows.Forms.Padding(15, 8, 15, 15);
            this.pnRightCenter.Size = new System.Drawing.Size(381, 337);
            this.pnRightCenter.TabIndex = 0;
            // 
            // gbNote
            // 
            this.gbNote.Controls.Add(this.rtbNote);
            this.gbNote.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbNote.Location = new System.Drawing.Point(15, 8);
            this.gbNote.Name = "gbNote";
            this.gbNote.Padding = new System.Windows.Forms.Padding(12, 10, 12, 12);
            this.gbNote.Size = new System.Drawing.Size(351, 314);
            this.gbNote.TabIndex = 0;
            this.gbNote.TabStop = false;
            this.gbNote.Text = "Note";
            // 
            // rtbNote
            // 
            this.rtbNote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbNote.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbNote.Location = new System.Drawing.Point(12, 29);
            this.rtbNote.Name = "rtbNote";
            this.rtbNote.Size = new System.Drawing.Size(327, 273);
            this.rtbNote.TabIndex = 0;
            this.rtbNote.Text = "- Parent Folder: The parent folder as user selected for Deliverable\n- Program Lan" +
    "guage: get from the name of Excel file\n- (1), (2): Project item\n- (a), (b): Deta" +
    "il of project";
            // 
            // gbExample
            // 
            this.gbExample.Controls.Add(this.treeView);
            this.gbExample.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbExample.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbExample.Location = new System.Drawing.Point(15, 8);
            this.gbExample.Name = "gbExample";
            this.gbExample.Padding = new System.Windows.Forms.Padding(10);
            this.gbExample.Size = new System.Drawing.Size(608, 314);
            this.gbExample.TabIndex = 0;
            this.gbExample.TabStop = false;
            this.gbExample.Text = "Example";
            // 
            // treeView
            // 
            this.treeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView.Location = new System.Drawing.Point(10, 29);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(588, 275);
            this.treeView.TabIndex = 3;
            // 
            // CreateDeliverableFolder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 610);
            this.Controls.Add(this.HeaderPanel);
            this.Controls.Add(this.FooterPanel);
            this.Name = "CreateDeliverableFolder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Deliverable folder base on Purchase specification (Excel file)";
            this.FooterPanel.ResumeLayout(false);
            this.HeaderPanel.ResumeLayout(false);
            this.PanelRow1.ResumeLayout(false);
            this.PanelRow1.PerformLayout();
            this.PanelRow3.ResumeLayout(false);
            this.gbCenter.ResumeLayout(false);
            this.pnLeftCenter.ResumeLayout(false);
            this.pnRightCenter.ResumeLayout(false);
            this.gbNote.ResumeLayout(false);
            this.gbExample.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel FooterPanel;
        private System.Windows.Forms.Label lbRightFotter;
        private System.Windows.Forms.Panel RightPanelFooter;
        private System.Windows.Forms.Label lbFooter;
        private System.Windows.Forms.Panel line;
        private System.Windows.Forms.TableLayoutPanel HeaderPanel;
        private System.Windows.Forms.Panel PanelRow1;
        private System.Windows.Forms.Label lbSelectFile;
        private System.Windows.Forms.TextBox tbSelectFile;
        private System.Windows.Forms.TextBox tbSelectParentFolder;
        private System.Windows.Forms.Label lbSelectParentFolder;
        private System.Windows.Forms.Button btBrowseFolder;
        private System.Windows.Forms.Button btBrowseExFile;
        private System.Windows.Forms.Panel PanelRow3;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btApply;
        private System.Windows.Forms.GroupBox gbCenter;
        private System.Windows.Forms.Panel pnLeftCenter;
        private System.Windows.Forms.Panel pnRightCenter;
        private System.Windows.Forms.GroupBox gbNote;
        private System.Windows.Forms.RichTextBox rtbNote;
        private System.Windows.Forms.Button btLoad;
        private System.Windows.Forms.GroupBox gbExample;
        private System.Windows.Forms.TreeView treeView;
    }
}