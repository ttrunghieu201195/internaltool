﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace demo
{
    public partial class CreateDeliverableFolder : Form
    {
        private FolderBrowserDialog folderBrowserDialog;
        private string folderPath, folderName;
        private string filePath, fileName;
        private ArrayList listParentNode;
        private ArrayList listChildNode;

        public CreateDeliverableFolder()
        {
            InitializeComponent();
            btLoad.Select();
            initTree();
        }

        public void initTree()
        {
            TreeNode[] childNode1 = new TreeNode[2];
            childNode1[0] = new TreeNode("(a) Swing");
            childNode1[1] = new TreeNode("(b) Pattern");
            TreeNode[] childNode2 = new TreeNode[2];
            childNode2[0] = new TreeNode("(a) Window Form");
            childNode2[1] = new TreeNode("(b) Web");
            TreeNode[] parentNode = new TreeNode[2];
            parentNode[0] = new TreeNode("(1) Java");
            parentNode[0].Nodes.Add(childNode1[0]);
            parentNode[0].Nodes.Add(childNode1[1]);
            parentNode[1] = new TreeNode("(2) C#");
            parentNode[1].Nodes.Add(childNode2[0]);
            parentNode[1].Nodes.Add(childNode2[1]);
            String rootName = "Parent Folder";
            String nameFile = "Program Language";
            setTreeElement(rootName, nameFile, parentNode);
        }

        public void setTreeElement(String rootName, String nameFile, TreeNode[] parentNode)
        {
            TreeNode file = new TreeNode(nameFile);
            TreeNode root = new TreeNode(rootName);
            for (int i = 0; i < parentNode.Length; i++)
            {
                if (parentNode[i] == null) continue;
                file.Nodes.Add(parentNode[i]);
            }
            root.Nodes.Add(file);
            treeView.Nodes.Clear();
            treeView.Nodes.Add(root);
            treeView.ExpandAll();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btBrowseExFile_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Excel 97-2003 Files (*.xls)|*.xls|Excel Wordbook Files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            tbSelectFile.Text = openFileDialog1.FileName;
                            myStream.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void btBrowseFolder_Click(object sender, EventArgs e)
        {
            // Show the FolderBrowserDialog.
            folderBrowserDialog = new FolderBrowserDialog();
            DialogResult result = folderBrowserDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbSelectParentFolder.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void btApply_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listParentNode.Count; i++)
            {
                Directory.CreateDirectory(folderPath + "\\" + listParentNode[i].ToString());
            }

            for (int i = 0; i < listChildNode.Count; i++)
            {
                Directory.CreateDirectory(folderPath + "\\" + listChildNode[i].ToString());
            }
        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            folderPath = tbSelectParentFolder.Text;
            filePath = tbSelectFile.Text;
            folderName = folderPath.Substring(folderPath.LastIndexOf("\\") + 1);
            fileName = filePath.Substring(filePath.LastIndexOf("\\") + 1);
            if(folderName.Trim().Equals("") && fileName.Trim().Equals(""))
            {
                MessageBox.Show("Choose your file and folder first!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (File.Exists(filePath) && Directory.Exists(folderPath))
            {
                ArrayList list = getDataFromFileExcel();
                int count = 0;
                string content;
                string bullet;
                TreeNode[] parentNode = new TreeNode[list.Count];
                listParentNode = new ArrayList();
                listChildNode = new ArrayList();
                string specialCharacter = "/\\|:?<>";

                for (int i = 0; i < list.Count; i++)
                {
                    content = list[i].ToString();
                    //filter special character: /,\,|,:,?,",<,>
                    for (int j = 0; j < specialCharacter.Length; j++)
                    {
                        if (content.Contains(specialCharacter[j]))
                        {
                            content = content.Replace(content.ElementAt(content.IndexOf(specialCharacter[j])).ToString()," , ");
                        }
                    }
                    bullet = content.Substring(content.IndexOf("(") + 1, content.IndexOf(")") - 1);
                    if (bullet.ElementAt(0) >= 'a' && bullet.ElementAt(0) <= 'z')
                    {
                        //It is child
                        count--;
                        parentNode[count].Nodes.Add(content);
                        listChildNode.Add(parentNode[count].Text.Trim() + "\\" + content.Trim());
                        count++; //keep index of parent
                    } else
                    {
                        //It is parent
                        parentNode[count] = new TreeNode(content.Trim());
                        listParentNode.Add(content);
                        count++;
                    }
                }
                setTreeElement(folderName, fileName.Substring(0, fileName.LastIndexOf(".")), parentNode);
                btApply.Enabled = true;
                gbExample.Text = "Your folders will be created as below";
            } else
            {
                MessageBox.Show("File or Folder does not exist!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public ArrayList getDataFromFileExcel()
        {
            ArrayList list = new ArrayList();
            Excel.Application xls = new Excel.Application();
            Excel.Workbook xlsWB = xls.Workbooks.Open(filePath);
            Excel.Worksheet xlsSheet = xlsWB.Sheets[1];
            Excel.Range xlsRange = xlsSheet.UsedRange;
            //get range of "Project Deliverable" data
            int rowBegin = -1;
            int rowEnd = -1;
            for (int i = 1; i <= xlsRange.Rows.Count; i++)
            {
                //column 2 is Column title
                if (xlsRange.Cells[i, 2] != null && xlsRange.Cells[i, 2].Value2 != null)
                {
                    if ("Project Deliverable".Equals((xlsRange.Cells[i, 2].Value).Trim()) && rowBegin == -1)
                    {
                        rowBegin = i;
                    }
                    if ("Date Of Delivery".Equals((xlsRange.Cells[i, 2].Value).Trim()) && rowEnd == -1)
                    {
                        rowEnd = i;
                        break;
                    }
                }
            }
            rowBegin--; //skip "Project Deliverable" Japan languge
            rowEnd = rowEnd - 2; //skip "Date Of Delivery" Japan languge
            xlsRange = xlsSheet.get_Range("C" + rowBegin, "C" + rowEnd);
            for (int i = 1; i <= xlsRange.Rows.Count; i++)
            {
                //Only 1 column is available here which is data of "Project Deliverable"
                if (xlsRange.Cells[i, 1] != null && xlsRange.Cells[i, 1].Value2 != null)
                {
                    list.Add(xlsRange.Cells[i, 1].Value);
                }
            }
            //close Excel not working
            NAR(xlsRange);
            NAR(xlsSheet);
            xlsWB.Close(false, Type.Missing, Type.Missing);
            NAR(xlsWB);
            xls.Quit();
            NAR(xls);

            return list;
        }

        protected void NAR(object o)
        {
            try
            {
                if (o != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(o);
            }
            catch (Exception e)
            {
                // Do nothing
            }
            finally
            {
                o = null;
            }
        }
    }
}
