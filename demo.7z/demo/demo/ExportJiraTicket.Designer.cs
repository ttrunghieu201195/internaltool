﻿namespace demo
{
    partial class ExportJiraTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportJiraTicket));
            this.ToolBar = new System.Windows.Forms.ToolStrip();
            this.tbInput = new System.Windows.Forms.ToolStripTextBox();
            this.BrowseContent = new System.Windows.Forms.WebBrowser();
            this.lbInput = new System.Windows.Forms.ToolStripLabel();
            this.searchButton = new System.Windows.Forms.ToolStripButton();
            this.lbExample = new System.Windows.Forms.ToolStripLabel();
            this.lbSpace = new System.Windows.Forms.ToolStripLabel();
            this.lbUrl = new System.Windows.Forms.ToolStripLabel();
            this.processBar = new System.Windows.Forms.ToolStripProgressBar();
            this.lbAccess = new System.Windows.Forms.ToolStripLabel();
            this.lbUserName = new System.Windows.Forms.ToolStripLabel();
            this.ToolBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolBar
            // 
            this.ToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lbInput,
            this.tbInput,
            this.lbExample,
            this.searchButton,
            this.lbSpace,
            this.lbAccess,
            this.processBar,
            this.lbUrl,
            this.lbUserName});
            this.ToolBar.Location = new System.Drawing.Point(0, 0);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.Size = new System.Drawing.Size(1164, 28);
            this.ToolBar.TabIndex = 0;
            this.ToolBar.Text = "toolStrip1";
            // 
            // tbInput
            // 
            this.tbInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbInput.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInput.Name = "tbInput";
            this.tbInput.Size = new System.Drawing.Size(200, 28);
            this.tbInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbInput_KeyDown);
            // 
            // BrowseContent
            // 
            this.BrowseContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BrowseContent.Location = new System.Drawing.Point(0, 28);
            this.BrowseContent.MinimumSize = new System.Drawing.Size(20, 20);
            this.BrowseContent.Name = "BrowseContent";
            this.BrowseContent.Size = new System.Drawing.Size(1164, 654);
            this.BrowseContent.TabIndex = 1;
            this.BrowseContent.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.BrowseContent_DocumentCompleted);
            this.BrowseContent.ProgressChanged += new System.Windows.Forms.WebBrowserProgressChangedEventHandler(this.BrowseContent_ProgressChanged);
            // 
            // lbInput
            // 
            this.lbInput.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInput.Name = "lbInput";
            this.lbInput.Size = new System.Drawing.Size(150, 25);
            this.lbInput.Text = "Type the key of ticket";
            // 
            // searchButton
            // 
            this.searchButton.AutoSize = false;
            this.searchButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.searchButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Image = ((System.Drawing.Image)(resources.GetObject("searchButton.Image")));
            this.searchButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(25, 25);
            this.searchButton.Text = "Search";
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // lbExample
            // 
            this.lbExample.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbExample.Name = "lbExample";
            this.lbExample.Size = new System.Drawing.Size(124, 25);
            this.lbExample.Text = "(Example: IDE-1234)";
            // 
            // lbSpace
            // 
            this.lbSpace.Name = "lbSpace";
            this.lbSpace.Size = new System.Drawing.Size(16, 25);
            this.lbSpace.Text = "   ";
            // 
            // lbUrl
            // 
            this.lbUrl.Name = "lbUrl";
            this.lbUrl.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.lbUrl.Size = new System.Drawing.Size(30, 25);
            // 
            // processBar
            // 
            this.processBar.AutoSize = false;
            this.processBar.Name = "processBar";
            this.processBar.Size = new System.Drawing.Size(100, 20);
            this.processBar.Visible = false;
            // 
            // lbAccess
            // 
            this.lbAccess.Name = "lbAccess";
            this.lbAccess.Size = new System.Drawing.Size(43, 25);
            this.lbAccess.Text = "Access";
            this.lbAccess.Visible = false;
            // 
            // lbUserName
            // 
            this.lbUserName.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lbUserName.Name = "lbUserName";
            this.lbUserName.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.lbUserName.Size = new System.Drawing.Size(30, 25);
            // 
            // ExportJiraTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 682);
            this.Controls.Add(this.BrowseContent);
            this.Controls.Add(this.ToolBar);
            this.Name = "ExportJiraTicket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Export Jira ticket into PDF/HTML file";
            this.ToolBar.ResumeLayout(false);
            this.ToolBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip ToolBar;
        private System.Windows.Forms.ToolStripTextBox tbInput;
        private System.Windows.Forms.WebBrowser BrowseContent;
        private System.Windows.Forms.ToolStripLabel lbInput;
        private System.Windows.Forms.ToolStripButton searchButton;
        private System.Windows.Forms.ToolStripLabel lbExample;
        private System.Windows.Forms.ToolStripLabel lbSpace;
        private System.Windows.Forms.ToolStripLabel lbUrl;
        private System.Windows.Forms.ToolStripProgressBar processBar;
        private System.Windows.Forms.ToolStripLabel lbAccess;
        private System.Windows.Forms.ToolStripLabel lbUserName;
    }
}