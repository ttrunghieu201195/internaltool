﻿namespace demo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ParentPanel = new System.Windows.Forms.Panel();
            this.FooterPanel = new System.Windows.Forms.Panel();
            this.lbRightFotter = new System.Windows.Forms.Label();
            this.RightPanelFooter = new System.Windows.Forms.Panel();
            this.lbFooter = new System.Windows.Forms.Label();
            this.line = new System.Windows.Forms.Panel();
            this.HeaderPanel = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cbFeature = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btGO = new System.Windows.Forms.Button();
            this.TitlePanel = new System.Windows.Forms.Panel();
            this.lbTitle = new System.Windows.Forms.Label();
            this.ParentPanel.SuspendLayout();
            this.FooterPanel.SuspendLayout();
            this.HeaderPanel.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.TitlePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ParentPanel
            // 
            this.ParentPanel.Controls.Add(this.FooterPanel);
            this.ParentPanel.Controls.Add(this.HeaderPanel);
            this.ParentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentPanel.Location = new System.Drawing.Point(0, 0);
            this.ParentPanel.Name = "ParentPanel";
            this.ParentPanel.Size = new System.Drawing.Size(785, 454);
            this.ParentPanel.TabIndex = 1;
            // 
            // FooterPanel
            // 
            this.FooterPanel.BackColor = System.Drawing.Color.White;
            this.FooterPanel.Controls.Add(this.lbRightFotter);
            this.FooterPanel.Controls.Add(this.RightPanelFooter);
            this.FooterPanel.Controls.Add(this.lbFooter);
            this.FooterPanel.Controls.Add(this.line);
            this.FooterPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.FooterPanel.Location = new System.Drawing.Point(0, 411);
            this.FooterPanel.Name = "FooterPanel";
            this.FooterPanel.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.FooterPanel.Size = new System.Drawing.Size(785, 43);
            this.FooterPanel.TabIndex = 2;
            // 
            // lbRightFotter
            // 
            this.lbRightFotter.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbRightFotter.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRightFotter.ForeColor = System.Drawing.Color.Gray;
            this.lbRightFotter.Location = new System.Drawing.Point(460, 19);
            this.lbRightFotter.Name = "lbRightFotter";
            this.lbRightFotter.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.lbRightFotter.Size = new System.Drawing.Size(195, 24);
            this.lbRightFotter.TabIndex = 3;
            this.lbRightFotter.Text = "BIG IDEAS FOR EVERY SPACE";
            // 
            // RightPanelFooter
            // 
            this.RightPanelFooter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RightPanelFooter.BackgroundImage")));
            this.RightPanelFooter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RightPanelFooter.Dock = System.Windows.Forms.DockStyle.Right;
            this.RightPanelFooter.Location = new System.Drawing.Point(655, 19);
            this.RightPanelFooter.Name = "RightPanelFooter";
            this.RightPanelFooter.Size = new System.Drawing.Size(100, 24);
            this.RightPanelFooter.TabIndex = 2;
            // 
            // lbFooter
            // 
            this.lbFooter.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbFooter.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFooter.ForeColor = System.Drawing.Color.Blue;
            this.lbFooter.Location = new System.Drawing.Point(30, 19);
            this.lbFooter.Name = "lbFooter";
            this.lbFooter.Padding = new System.Windows.Forms.Padding(0, 1, 0, 0);
            this.lbFooter.Size = new System.Drawing.Size(141, 24);
            this.lbFooter.TabIndex = 1;
            this.lbFooter.Text = "Release: Aug 30, 2017";
            // 
            // line
            // 
            this.line.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("line.BackgroundImage")));
            this.line.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.line.Dock = System.Windows.Forms.DockStyle.Top;
            this.line.Location = new System.Drawing.Point(30, 0);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(725, 19);
            this.line.TabIndex = 0;
            // 
            // HeaderPanel
            // 
            this.HeaderPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HeaderPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("HeaderPanel.BackgroundImage")));
            this.HeaderPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HeaderPanel.Controls.Add(this.tableLayoutPanel2);
            this.HeaderPanel.Controls.Add(this.tableLayoutPanel1);
            this.HeaderPanel.Controls.Add(this.TitlePanel);
            this.HeaderPanel.Location = new System.Drawing.Point(0, 0);
            this.HeaderPanel.Margin = new System.Windows.Forms.Padding(0);
            this.HeaderPanel.Name = "HeaderPanel";
            this.HeaderPanel.Padding = new System.Windows.Forms.Padding(0, 0, 0, 60);
            this.HeaderPanel.Size = new System.Drawing.Size(785, 413);
            this.HeaderPanel.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.cbFeature, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 237);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(785, 73);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // cbFeature
            // 
            this.cbFeature.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbFeature.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFeature.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFeature.FormattingEnabled = true;
            this.cbFeature.Items.AddRange(new object[] {
            " Create Deliverable folder base on Purchase specification (Excel file)",
            " Export JIRA ticket into PDF/HTML file"});
            this.cbFeature.Location = new System.Drawing.Point(120, 3);
            this.cbFeature.Name = "cbFeature";
            this.cbFeature.Size = new System.Drawing.Size(543, 28);
            this.cbFeature.TabIndex = 8;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42F));
            this.tableLayoutPanel1.Controls.Add(this.btGO, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 310);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(785, 43);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // btGO
            // 
            this.btGO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btGO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGO.Location = new System.Drawing.Point(332, 3);
            this.btGO.Name = "btGO";
            this.btGO.Size = new System.Drawing.Size(119, 37);
            this.btGO.TabIndex = 0;
            this.btGO.Text = "LET\'S GO";
            this.btGO.UseVisualStyleBackColor = true;
            this.btGO.Click += new System.EventHandler(this.btGO_Click);
            // 
            // TitlePanel
            // 
            this.TitlePanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TitlePanel.BackColor = System.Drawing.Color.MediumBlue;
            this.TitlePanel.Controls.Add(this.lbTitle);
            this.TitlePanel.Location = new System.Drawing.Point(12, 12);
            this.TitlePanel.Name = "TitlePanel";
            this.TitlePanel.Size = new System.Drawing.Size(761, 68);
            this.TitlePanel.TabIndex = 0;
            // 
            // lbTitle
            // 
            this.lbTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.ForeColor = System.Drawing.Color.White;
            this.lbTitle.Location = new System.Drawing.Point(3, 17);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(312, 33);
            this.lbTitle.TabIndex = 0;
            this.lbTitle.Text = "DELIVERABLE TOOL v1.0";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 459);
            this.Controls.Add(this.ParentPanel);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Renesas Design Vietnam";
            this.ParentPanel.ResumeLayout(false);
            this.FooterPanel.ResumeLayout(false);
            this.HeaderPanel.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.TitlePanel.ResumeLayout(false);
            this.TitlePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ParentPanel;
        private System.Windows.Forms.Panel HeaderPanel;
        private System.Windows.Forms.Panel TitlePanel;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Panel FooterPanel;
        private System.Windows.Forms.Panel line;
        private System.Windows.Forms.Label lbFooter;
        private System.Windows.Forms.Panel RightPanelFooter;
        private System.Windows.Forms.Label lbRightFotter;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ComboBox cbFeature;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btGO;
    }
}

