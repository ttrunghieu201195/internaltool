﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            buildGUI();
        }

        public void buildGUI()
        {
            cbFeature.SelectedIndex = 0;
            //cbFeature.Items.Add("");
        }

        private void btGO_Click(object sender, EventArgs e)
        {
            int itemIndex = cbFeature.SelectedIndex;
            switch (itemIndex)
            {
                case 0:
                    if (Application.OpenForms.OfType<CreateDeliverableFolder>().Count() == 0)
                    {
                        //Application.OpenForms.OfType<CreateDeliverableFolder>().First().Close(); if == 1
                        CreateDeliverableFolder cdf = new CreateDeliverableFolder();
                        cdf.Show();
                        WindowState = FormWindowState.Minimized;
                    }
                    break;
                case 1:
                    if (Application.OpenForms.OfType<ExportJiraTicket>().Count() == 0)
                    {
                        ExportJiraTicket ejt = new ExportJiraTicket();
                        ejt.Show();
                        WindowState = FormWindowState.Minimized;
                    }
                    break;
            }
        }
    }
}
