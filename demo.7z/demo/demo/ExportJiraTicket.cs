﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class ExportJiraTicket : Form
    {
        private string key = "deliverabletool";
        private string userName = "";
        private string passWord = "";

        public ExportJiraTicket()
        {
            InitializeComponent();
            readFileLogin();
        }

        private void Navigate(String address)
        {
            if (String.IsNullOrEmpty(address)) return;
            if (address.Equals("about:blank")) return;
            if (!address.StartsWith("http://") &&
                !address.StartsWith("https://"))
            {
                address = "https://" + address;
            }
            try
            {
                BrowseContent.Navigate(new Uri(address));
                BrowseContent.ScriptErrorsSuppressed = true;
            }
            catch (System.UriFormatException)
            {
                return;
            }
        }

        // Login process
        private void autoLogin()
        {
            try
            {
                HtmlDocument doc = BrowseContent.Document;
                HtmlElement username = doc.GetElementById("login-form-username");
                HtmlElement password = doc.GetElementById("login-form-password");
                HtmlElement submit = doc.GetElementById("login");
                HtmlElement captcha = doc.GetElementById("captcha");
                username.SetAttribute("value", userName);
                password.SetAttribute("value", passWord);
                if (captcha == null)
                {
                    submit.InvokeMember("click");
                }
            }
            catch (System.Exception) { }
        }

        private void readFileLogin()
        {
            string filePath = Directory.GetCurrentDirectory() + "/user.lg";
            string loginInfo;
            if (File.Exists(filePath))
            {
                loginInfo = File.ReadAllText(filePath);
                userName = loginInfo.Substring(0, loginInfo.IndexOf("\n")).Trim();
                passWord = loginInfo.Substring(loginInfo.IndexOf("\n")).Trim();
                passWord = decryption(passWord);
                lbUserName.Text = "User: " + userName;
            } else
            {
                Form loginForm = new Form()
                {
                    Width = 400,
                    Height = 220,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = "Login to Jira",
                    StartPosition = FormStartPosition.CenterScreen
                };
                Label lbUser = new Label() { Left = 40, Top = 20, Text = "Username: " };
                TextBox tbUser = new TextBox() { Left = 40, Top = 50, Width = 300 };
                Label lbPass = new Label() { Left = 40, Top = 80, Text = "Password: " };
                TextBox tbPass = new TextBox() { Left = 40, Top = 110, Width = 300 };
                tbPass.PasswordChar = '*';
                Button confirmation = new Button() { Text = "OK", Left = 270, Width = 70, Top = 150, DialogResult = DialogResult.OK };
                confirmation.Click += (sender, e) => { loginForm.Close(); };
                loginForm.Controls.Add(lbUser);
                loginForm.Controls.Add(tbUser);
                loginForm.Controls.Add(lbPass);
                loginForm.Controls.Add(tbPass);
                loginForm.Controls.Add(confirmation);
                loginForm.AcceptButton = confirmation;

                loginForm.MaximizeBox = false;
                if(loginForm.ShowDialog() == DialogResult.OK)
                {
                    if(!String.IsNullOrEmpty(tbUser.Text.Trim()) && !String.IsNullOrEmpty(tbPass.Text.Trim()))
                    {
                        userName = tbUser.Text;
                        passWord = tbPass.Text;
                        lbUserName.Text = "User: " + userName;
                        File.WriteAllLines(filePath, new string[]{userName, encryption(passWord)});
                    }
                }
            }
        }

        private string encryption(string passPlainText)
        {
            StringBuilder sbPassword = new StringBuilder();
            int temp;
            while (passPlainText.Length > key.Length)
            {
                key += key;
            }
            for (int i = 0; i < passPlainText.Length; i++)
            {
                temp = passPlainText.ElementAt(i) + key.ElementAt(i);
                temp *= 9;
                sbPassword.Insert(i, (char) temp);
            }
            key = "deliverabletool";
            return sbPassword.ToString();
        }

        private string decryption(string passEncryption)
        {
            StringBuilder sbPassword = new StringBuilder();
            int temp;
            while (passEncryption.Length > key.Length)
            {
                key += key;
            }
            for (int i = 0; i < passEncryption.Length; i++)
            {
                temp = passEncryption.ElementAt(i) / 9;
                temp -= key.ElementAt(i);
                sbPassword.Insert(i, (char)temp);
            }
            key = "deliverabletool";
            return sbPassword.ToString();
        }

        private void browseTheWeb()
        {
            string url = tbInput.Text;
            processBar.Visible = true;
            lbAccess.Visible = true;
            url = url.ToUpper();
            url = "jira.renesas.eu/browse/" + url;
            lbUrl.Text = "https://" + url;
            Navigate(url);
        }

        // Event GUI

        private void tbInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                browseTheWeb();
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            browseTheWeb();
        }

        private void BrowseContent_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            try
            {
                processBar.Value = Convert.ToInt32(e.CurrentProgress);
                processBar.Maximum = Convert.ToInt32(e.MaximumProgress);
            } catch (Exception ex)
            {
                //MessageBox.Show("Cann't load the page!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BrowseContent_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            autoLogin();
        }
    }
}
